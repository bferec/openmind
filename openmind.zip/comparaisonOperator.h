/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* comparaisonOperator.h		*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

expression_Value expression_Operator_T_DIFFERENT( operator * oneOperatorNode  );
expression_Value expression_Operator_T_EQUAL( operator * oneOperatorNode  );

expression_Value expression_Operator_T_LESS_THAN( operator * oneOperatorNode  );
expression_Value expression_Operator_T_MORE_THAN( operator * oneOperatorNode  );
expression_Value expression_Operator_T_LESS_OR_EQUAL_THAN( operator * oneOperatorNode  );
expression_Value expression_Operator_T_MORE_OR_EQUAL_THAN( operator * oneOperatorNode  );
