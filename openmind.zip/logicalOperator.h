/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* logicalOperator.h			*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

expression_Value expression_Operator_T_OR( operator * oneOperatorNode  );
expression_Value expression_Operator_T_AND( operator * oneOperatorNode  );
expression_Value expression_Operator_T_NOT( operator * oneOperatorNode  );
expression_Value expression_Operator_T_XOR( operator * oneOperatorNode  );

