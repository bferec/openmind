/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* binaryOperator.h			*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

expression_Value expression_Operator_T_BINARY_OR( operator * oneOperatorNode  );
expression_Value expression_Operator_T_BINARY_AND( operator * oneOperatorNode  );
expression_Value expression_Operator_T_BINARY_COMPLEMENT( operator * oneOperatorNode  );
expression_Value expression_Operator_T_LEFT_SHIFT( operator * oneOperatorNode  );
expression_Value expression_Operator_T_RIGHT_SHIFT( operator * oneOperatorNode  );


