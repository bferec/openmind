/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* alternatOperator.h			*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

void expression_Operator_T_IF(operator * oneOperatorNode);
expression_Value expression_Operator_T_QUESTION( operator * oneOperatorNode  ) ; 


