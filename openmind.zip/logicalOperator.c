/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* logicalOperator.c			*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "openmindlib.h"
#include "entity.h"
#include "openmindvalue.h"
#include "openmindvarlist.h"
#include "openmindconstant.h"
#include "operator.h"
#include "syntaxtree.h"

#include "expressions.h"

#include "openmind.tab.h"


expression_Value expression_Operator_T_OR( operator * oneOperatorNode  )
{
expression_Value result;
expression_Value * operandResult ;

	return result;
}

expression_Value expression_Operator_T_AND( operator * oneOperatorNode  )
{
expression_Value result;
expression_Value * operandResult ;

	return result;
}

expression_Value expression_Operator_T_NOT( operator * oneOperatorNode  )
{
expression_Value result;
expression_Value * operandResult ;

	return result;
}



