/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* iterOperator.h			*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

void expression_Operator_T_WHILE(operator * oneOperatorNode);
void expression_Operator_T_DO(operator * oneOperatorNode);
void expression_Operator_T_FOR(operator * oneOperatorNode);




