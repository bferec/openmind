/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* arithmeticOperator.h			*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/


expression_Value expression_Operator_T_PLUS_SIGN( operator * oneOperatorNode  );
expression_Value expression_Operator_T_MINUS_SIGN( operator * oneOperatorNode  );
expression_Value expression_Operator_T_ASTERISK( operator * oneOperatorNode  );
expression_Value expression_Operator_T_SLASH( operator * oneOperatorNode  );


