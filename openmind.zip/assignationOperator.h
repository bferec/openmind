/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* assignationOperator.h		*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

expression_Value  expression_Operator_T_ASSIGN(operator * oneOperatorNode);
expression_Value  expression_Operator_T_PLUS_EGAL_SIGN(operator * oneOperatorNode);
expression_Value  expression_Operator_T_MINUS_EGAL_SIGN(operator * oneOperatorNode);
expression_Value  expression_Operator_T_ASTERISK_EGAL(operator * oneOperatorNode);
expression_Value  expression_Operator_T_SLASH_EGAL(operator * oneOperatorNode);


