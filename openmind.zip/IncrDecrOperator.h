/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* IncrDecrOperator.h			*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

expression_Value  expression_Operator_T_INCR(operator * oneOperatorNode);
expression_Value  expression_Operator_T_DECR(operator * oneOperatorNode);



