/* openmindlib.h	*/

#define GUID_LENGTH 33
#define MAXLENGTH_STRING 255
#define BOOL int

void NewGuid( char * result );



