/* -----------------------------------------------------*/
/* -----------------------------------------------------*/
/* 							*/
/* debugTools.h						*/
/* 							*/
/* -----------------------------------------------------*/
/* -----------------------------------------------------*/

char * getOperandeTypeLibelle( syntaxTreeNode * oneNode );
char *  getOperatorLibelle( int oneOperatorType );
void  dumpSyntaxTreeNode(syntaxTreeNode * oneNode );

