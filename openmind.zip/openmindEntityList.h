/* -------------------------------------*/
/* -------------------------------------*/
/* 					*/
/* openmindEntityList.h			*/
/* 					*/
/* -------------------------------------*/
/* -------------------------------------*/

extern entity_node * entity_list;

void addEntityNodeToList( entity_node * oneEntityNode );
void ClearEntityList();
